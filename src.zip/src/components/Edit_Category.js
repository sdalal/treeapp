﻿import React, { Component } from 'react';

class Edit_Category extends Component {

    render() {
        return (
            <div>Display edit Item </div>
        );
    }
}

export default Edit_Category;


