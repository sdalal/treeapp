﻿import React from "react";

export class Edit_ProdTemplate extends React.Component {
	static displayName = Edit_ProdTemplate.name;

	constructor(props) {
		super(props);
		this.state = {
		}

	}


	render() {
		return (
			<div>
				Edit_ProdTemplate
			</div>

		);
	}
}

export default Edit_ProdTemplate;