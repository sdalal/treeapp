﻿import React from "react";


export class Edit_Product extends React.Component {
	static displayName = Edit_Product.name;

	constructor(props) {
		super(props);
		this.state = {
				}

	}


	render() {
		return (
			<div>
				Edit_Product
			</div>

		);
	}
}

export default Edit_Product;