import React, { Component } from 'react';
import "../App.css";
import ProductsTree from './ProductsTreeView';

class Home extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            currentNode: {},
        };
        this.setCurrentNode = this.setCurrentNode.bind(this);
    }

    setCurrentNode(node) {
        this.setState({ currentNode: node });
    }
    render() {
        return (
           <div className="container">
        		<div className="TreeContainer">
                    <table width="100%" border="0" cellSpacing="0" cellPadding="0">
                        <tbody>
                            <tr width="100%">
                                <td align="left" nowrap="true">
                                                 <b><a href="">Expand All</a></b>
                                 </td><td>
                                                <b><a href="">Collapse All</a></b>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br />
                  
                          
                                <p align="center">Products</p>
                                <ProductsTree setCurrentNode={this.setCurrentNode} />
                           

                </div>
                <div className="BodyContainer">
                  
                    <p>Data needs to display here </p>
                    {this.state.currentNode.description}<br />
                    {this.state.currentNode.id}<br />
                    {this.state.currentNode.key_id} <br />
                    {this.state.currentNode.linkpagename}
                </div>

               

            </div>
        );
    }
}

export default Home;

