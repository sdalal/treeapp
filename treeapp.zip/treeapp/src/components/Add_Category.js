﻿import React, { Component } from 'react';

class Add_Category extends Component {

    render() {
        return (
            <div>Display Add Item </div>
        );
    }
}

export default Add_Category;


