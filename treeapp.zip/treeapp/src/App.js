import React, { Component } from 'react';
import React, { Component } from 'react';
import { Switch, Route, Link } from "react-router-dom";
import { BrowserRouter } from 'react-router-dom';
import Home from './components/Home';
import Add_Category from './components/Add_Category';
import Edit_Category from './components/Edit_Category';
import Edit_Product from './components/Edit_Product';
import Edit_ProdTemplate from './components/Edit_ProdTemplate';

export class App extends Component {
  constructor(props) {
    super(props);
  }

render() {
    return (
        <div>
        <BrowserRouter>
            <Switch>
                <Route path="/Add_Category" component={Add_Category} />
                    <Route path="/Edit_Category" component={Edit_Category} />
                <Route path="/Edit_Product" component={Edit_Product} />
                <Route path="/Edit_ProdTemplate" component={Edit_ProdTemplate} />
                {/* Otherwise, render the Landing component */}
                <Route component={Home} />
            </Switch>
            </BrowserRouter>
            </div>
    );
}
}

export default App;
